<?php

class ftp_login
{
private $ip;
private $username;
private $password;
private $domain;
private $all_data;
private $data;
private $file = [];
private $folder = [];
private $response = [];

	function __construct(){
			$this->ip  = $_POST['ip'];
			$this->username  = $_POST['email'];
			$this->password  = $_POST['password'];

			$this->domain = ftp_connect($this->ip);

			if(ftp_login($this->domain,$this->username,$this->password))
			{

			setcookie('_aus_', base64_encode($this->username), time()+(60*60*24*365), "/"); 

			setcookie('_aiap_', base64_encode($this->ip), time()+(60*60*24*365), "/"); 

			setcookie('_apsa_', base64_encode($this->password),time()+(60*60*24*365), "/"); 


				ftp_pasv($this->domain, true);

				if($this->all_data = ftp_nlist($this->domain, "."))
				{
				foreach ($this->all_data as $this->data) 
				{

						if(ftp_size($this->domain, $this->data) == -1)
						{

							array_push($this->folder, $this->data);
							
						}
						else
						{
							array_push($this->file, $this->data);
							
						}	
					}


					array_push($this->response, $this->file);
					array_push($this->response, $this->folder); 					
					echo json_encode($this->response);
				}
				else
				{
					echo "not connect";
				}



			}
			else
			{
				echo "not connect";
			}



	}
}


new ftp_login();

?>