<?php

class ftp_login
{
private $ip;
private $username;
private $password;
private $domain;
private $all_data;
private $data;
private $file = [];
private $folder = [];
private $response = [];

	function __construct(){
			$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
		$this->username  = base64_decode($_COOKIE['_aus_']);
		$this->password  = base64_decode($_COOKIE['_apsa_']);

			$this->domain = ftp_connect($this->ip);

			if(ftp_login($this->domain,$this->username,$this->password))
			{

						ftp_pasv($this->domain, true);

				if($this->all_data = ftp_nlist($this->domain, "."))
				{
				foreach ($this->all_data as $this->data) 
				{

						if(ftp_size($this->domain, $this->data) == -1)
						{

							array_push($this->folder, $this->data);
							
						}
						else
						{
							array_push($this->file, $this->data);
							
						}	
					}


					array_push($this->response, $this->file);
					array_push($this->response, $this->folder); 					
					echo json_encode($this->response);
				}
				else
				{
					echo "not connect";
				}



			}
			else
			{
				echo "not connect";
			}



	}
}


new ftp_login();

?>