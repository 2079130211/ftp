<?php

echo "ok"

exit;

class edit
{
private $ip;
private $username;
private $password;
private $path;
// private $file_name;
// private $all_data;
// private $data;
private $domain;
// private $file;

	function __construct(){


		$this->path = $_POST['path'];
		$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
		$this->username  = base64_decode($_COOKIE['_aus_']);
		$this->password  = base64_decode($_COOKIE['_apsa_']);	

		$this->domain = ftp_connect($this->ip);
		if(ftp_login($this->domain, $this->username, $this->password))
		{
			

		}
		else
		{
			echo "not connect";
		}


	}
}


new edit();

?>