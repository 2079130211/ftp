<?php


class delate_file
{

private $ip;
private $username;
private $password;
private $file_type;
private $file_name;
private $all_data;
private $data;
private $domain;
private $file;

	function __construct(){
		$this->file_name = $_POST['file_name'];
		$this->file_type = $_POST['file_type'];
		
				if($this->file_type == "file")
				{
					if(unlink($this->file_name))
					{
							echo "success";
						}
						else
						{
							echo "Download fail";
						}
				}
				else
				{
					if(unlink($this->file_name))
					{
							echo "success";
						}
						else
						{
							echo "Download fail";
						}
				}





		}
						
	}


new delate_file();

?>
