<?php


class ftp_login
{
private $ip;
private $username;
private $password;
private $domain;
private $all_data;
// private $data;
private $file = [];
private $folder = [];
private $response = [];
private $file_type;
private $file_name;
private $check;
private $check1;


	function __construct(){
		$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
		$this->username  = base64_decode($_COOKIE['_aus_']);
		$this->password  = base64_decode($_COOKIE['_apsa_']);	

		$this->file_type  = $_POST['file_type'];

		$this->file_name   = $_POST['file_name'];

		$this->domain = ftp_connect($this->ip);

			if(ftp_login($this->domain,$this->username,$this->password))
			{

				ftp_pasv($this->domain, true);

				$dir = opendir('ftp://'.$this->username.':'.$this->password.'@'.$this->ip.'/'.$this->file_name);

				while(($data = readdir($dir)) != false)
				{
					if(is_dir('ftp://'.$this->username.':'.$this->password.'@'.$this->ip.'/'.$this->file_name.'/'.$data))
						{

							array_push($this->folder, $data.'*'.$this->file_name.'/'.$data.'*'.$this->file_name);
							
						}
						else
						{
							array_push($this->file, $data.'*'.$this->file_name.'/'.$data.'*'.$this->file_name);
							
						}
				}

					array_push($this->response, $this->file);
					array_push($this->response, $this->folder); 					
					echo json_encode($this->response);

				



			}
			else
			{
				echo "not connect";
			}

		
	}
}


new ftp_login();

?>