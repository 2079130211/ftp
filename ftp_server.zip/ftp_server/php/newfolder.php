<?php

class new_file
{private $ip;
private $username;
private $password;
private $domain;
private $all_data;
private $data;
private $file = [];
private $folder = [];
private $response = [];
private $file_type;
private $file_name;
private $check;



	function __construct(){
		$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
		$this->username  = base64_decode($_COOKIE['_aus_']);
		$this->password  = base64_decode($_COOKIE['_apsa_']);	

		$this->file_type  = $_POST['file_type'];

		$this->file_name   = $_POST['file_name'];

		$this->check ='ftp://'.$this->username.':'.$this->password.'@'.$this->ip.'/'.$this->file_name;

		
			$this->domain = ftp_connect($this->ip);

			if(ftp_login($this->domain,$this->username,$this->password))
			{
				if($this->file_type == "folder")
					{

									if(is_dir($this->check))
									{

										echo "Folder is already exists";

									}
									else
									{

													if(ftp_mkdir($this->domain, $this->file_name))
													{
														echo "success";

													}
													else
													{
														echo "fail";

													}


									}
							}		

								else {
									
								if(file_exists($this->check))
								{

									echo "file is already exists";

								}
								else
								{						

								if(fopen($this->check, "w"))
								{
									echo "success";								

								}
								else
								{
									echo "fail";

								}


							}						
								
						}
			

			}
			else
			{
				echo "connection error";
			}

}
}


new new_file();

?>