<?php




class rename_code
{
private $ip;
private $username;
private $password;
private $domain;
private $oldname;
private $newname;
private $file_type;


	function __construct(){
		$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
		$this->username  = base64_decode($_COOKIE['_aus_']);
		$this->password  = base64_decode($_COOKIE['_apsa_']);	

		$this->oldname  = $_POST['oldname'];

		$this->newname   = $_POST['newname'];

		$this->file_type   = $_POST['file_type'];

		if($this->oldname == $this->newname)
		{
				echo "success";
		}
		else
		{	
			$this->domain = ftp_connect($this->ip);

			if(ftp_login($this->domain,$this->username,$this->password))
			{

				ftp_pasv($this->domain, true);

				// if($this->file_type== "folder")
				// {
				if(ftp_rename($this->domain, $this->oldname, $this->newname))
				{
					echo "success";
				}
				else
				{
					echo "fail";
				}
			// }
			// else
			// {
			// 	echo "file";

			// }

				



			}
			else
			{
				echo "not connect";
			}

		
			

}

	}
}


new rename_code();

?>