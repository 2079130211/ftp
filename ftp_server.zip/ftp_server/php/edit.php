<?php

class edit_file
{

private $ip;
private $username;
private $password;
private $file_type;
private $file_name;
private $data;
private $domain;
private $all_data = [];
private $file_path;


	function __construct(){
		$this->file_name = $_POST['file_name'];
		$this->file_type = $_POST['file_type'];

		// echo $this->file_name; //file ka path
		// echo "</br>";
		// echo $this->file_type; // file-name
		// exit;

		
		$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
			$this->username  = base64_decode($_COOKIE['_aus_']);
			$this->password  = base64_decode($_COOKIE['_apsa_']);

			$this->domain = ftp_connect($this->ip);		

		if(ftp_login($this->domain,$this->username,$this->password))
			{	
			ftp_pasv($this->domain, true);

			$this->file = fopen($this->file_name, "w");	


		if($this->file_type != "file")
		{
			$this->file_path = $this->file_type;	
		}	
		else
		{
			$this->file_path = $this->file_name;

		}




			if(ftp_fget($this->domain,  $this->file, $this->file_path, FTP_BINARY))
			{	
		
			$this->all_data =  ["<pre>".htmlspecialchars(file_get_contents($this->file_name),ENT_QUOTES)."</pre>",$this->file_name];

				echo json_encode($this->all_data);
			}
			else
			{
				echo "fail";
			}



		}
		else
		{
			echo "connection error";

		}

				
	}
}


new edit_file();

?>
