<?php


class delate_file
{

private $ip;
private $username;
private $password;
private $file_type;
private $file_name;
private $all_data;
private $data;
private $domain;
private $file;

	function __construct(){
		$this->file_name = $_POST['file_name'];
		$this->file_type = $_POST['file_type'];
		$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
		$this->username  = base64_decode($_COOKIE['_aus_']);
		$this->password  = base64_decode($_COOKIE['_apsa_']);

		$this->domain =  ftp_connect($this->ip);

		ftp_login($this->domain, $this->username, $this->password);

		ftp_pasv($this->domain, true);


			if($this->file_type != "file")
			{

		if(ftp_rmdir($this->domain, $this->file_name))
		{
			echo "success";
		}
		else
		{
			echo "fail";
		}

			}
			else
			{

		if(ftp_delete($this->domain , $this->file_name))
		{
			echo "success";
		}
		else
		{
			echo "fail";
		}

			}
		}
						
	}
new delate_file();

?>
