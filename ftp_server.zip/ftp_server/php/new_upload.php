<?php
class upload
{
private $ip;
private $username;
private $password;
private $file;
private $domain;
private $file_name;
private $tmp_name;
private $filedata;
private $back_path;
	function __construct(){
			$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
			
			$this->username  = base64_decode($_COOKIE['_aus_']);
			
			$this->password  = base64_decode($_COOKIE['_apsa_']);
			
			$this->file  = $_FILES['file'];

			$this->back_path = $_POST['back_path'];			
			
			$this->file_name =  $this->file['name']; 
			
			$this->tmp_name =  $this->file['tmp_name'];
						

			$this->domain = ftp_connect($this->ip);

			if(ftp_login($this->domain, $this->username, $this->password))
			{
				ftp_pasv($this->domain, true);

				
			$this->filedata = fopen($this->tmp_name, "r");

			if($this->back_path != "main")
			{
				$this->file_name = $this->back_path.'/'.$this->file_name;
			}

// echo $this->file_name;

// exit;
			

			if(ftp_fput($this->domain, $this->file_name, $this->filedata, FTP_BINARY))
			{
				echo "success";
			}
			else
			{
				echo "upload fail";
			}


			// }

			
			// 	else
			// 	{
			// 		echo "file is already exist";
			// 	}

				}
			else
			{
				echo "connection error please try again later";
			}		
	}
}
new upload();
?>
