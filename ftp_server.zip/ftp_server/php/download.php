<?php

class download
{

private $ip;
private $username;
private $password;
private $file_type;
private $file_name;
private $all_data;
private $data;
private $domain;
private $file;

	function __construct(){


		$this->file_name = $_POST['file_name'];
		$this->file_type = $_POST['file_type'];
		$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
			$this->username  = base64_decode($_COOKIE['_aus_']);
			$this->password  = base64_decode($_COOKIE['_apsa_']);

			$this->domain = ftp_connect($this->ip);
		

		if(ftp_login($this->domain,$this->username,$this->password))
			{	

			$this->file = fopen($this->file_name, "w");			

			ftp_pasv($this->domain, true);

			if(ftp_fget($this->domain, $this->file, $this->file_name, FTP_BINARY))
			{
				
				echo "success";

			}
			else
			{
				echo "Download fail";
			}





		}
		else
		{
			echo "connection error";

		}

				
	}
}


new download();

?>
