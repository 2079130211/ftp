<?php
	require("php/database.php");
	$branding_data = '';
$select_branding_table = "SELECT * FROM branding";
  $branding_response = $db->query($select_branding_table);
  if($branding_response){
    if($branding_response->num_rows != 0){
    	$branding_data = $branding_response->fetch_assoc();
    $logo_encoded_string = base64_encode($branding_data["brand_logo"]);
    $logo_string = "data:image/png;base64,".$logo_encoded_string;
    $brand_name = $branding_data["brand_name"];
    $brand_tagline = $branding_data["brand_tagline"];
    }

  }

?>

<!DOCTYPE html>
<html>
<head>
<title></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css2?family=Bitter:wght@700&display=swap" rel="stylesheet">
  <script src="js/jquery-1.9.1.min.js"></script>
  <script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/script.js"></script>
<script type="text/javascript" src="js/echo.min.js"></script>
<script>
	echo.init({
    callback: function (element, op) {
        console.log(element, 'has been', op + 'ed')
    }
});
</script>
</head>
<body>
	

<?php
include_once("assest/sidebar.php");

?>
<div class="page_box">
	<?php
	include_once("assest/header.php");
	?>
	<div class="container-fluid">
		<p id="result" class=" text-white"></p>
		<div class="row m-0">
			<div class="col-12 fisrt_banner">
				  <!--banner box-->
    <?php
$banner_box = "";
    $select_banner = "SELECT banner FROM con_status";
    $select_banner_responce = $db->query($select_banner);
    if($select_banner_responce){
      if($select_banner_responce->num_rows != 0){
      $banner_data = $select_banner_responce->fetch_assoc();
      if($banner_data["banner"] == "active"){
    
     $select_banner_table = "SELECT * FROM banner";
     $banner_table_responce = $db->query($select_banner_table);
     while($b_data = $banner_table_responce->fetch_assoc()){
      $b_image = "data:image/png;base64,".base64_encode($b_data["banner_image"]);
      echo '<img src="'.$b_image.'">';
     }
      }
    }
    }
?>
				
			</div>
		</div>
		<div class="row mt-3 overflow-hidden">
			<div class="col-md-6 news_row_first_div overflow-hidden">
				<h4 style="font-weight:bold;margin:5px;text-transform:capitalize;"><span style="color:#F30089"><?php echo $brand_name; ?></h4>
				<p style="color:#F30089;font-weight:bold;"><?php echo $brand_tagline; ?></p>

				
				<div class="news_con">
					
					
					
					
					
				</div>
				<!--end news box-->
					<div class="d-flex justify-content-center mt-2 read_more_btn">
						
					</div>
				
			</div>
			<div class="col-md-6">

				<div class="news_con_by_cat">
					
					<!--end news box-->
					
					
					
				</div>
			</div>

		</div>
		
	</div>
	 <?php
  	 include_once("assest/footer.php");
  ?>
</div>
</body>
</html>

