<?php


class edit_upload
{

private $ip;
private $username;
private $password;
private $file_data;
private $file_name;
private $domain;
private $all_data = [];
private $file;
private $back_path;


	function __construct(){
		$this->file_name = $_POST['file_name'];
		$this->back_path = $_POST['path'];
		$this->file_data = htmlspecialchars_decode($_POST['file_type']);

		$this->file = fopen($this->file_name, "w");

		if(fwrite($this->file, $this->file_data))
		{

			$this->ip  		 = base64_decode($_COOKIE['_aiap_']);
			$this->username  = base64_decode($_COOKIE['_aus_']);
			$this->password  = base64_decode($_COOKIE['_apsa_']);


			$this->domain =  ftp_connect($this->ip);


			if(ftp_login($this->domain, $this->username, $this->password))
			{
				
				$this->file = fopen($this->file_name, "r");
				
					ftp_pasv($this->domain, true);	

						
			if($this->back_path != "main")
			{
				$this->file_name = $this->back_path.'/'.$this->file_name;
			}
		


					if(ftp_fput($this->domain, $this->file_name, $this->file,  FTP_BINARY))
					{
						echo "success";
					}
					else
					{
						echo "fail";
					}


			}
			else
			{
				echo "connection error";
			}


			
		}
		else
		{
			echo "fail";
		}
		

				
	}
}


new edit_upload();

?>
