<?php

	$ip = "";
	$username = "";
	$password =  "";

if(!empty($_COOKIE['_aiap_']) && !empty($_COOKIE['_aiap_']) && !empty($_COOKIE['_aiap_']))
{

$ip= base64_decode($_COOKIE['_aiap_']);
$username  = base64_decode($_COOKIE['_aus_']);
$password  = base64_decode($_COOKIE['_apsa_']);
}

?>

<! DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="css/index.css" rel="stylesheet">

</head>
<body>


<div class="container ">

	<div class="row py-3 ">
		<div class="col-md-12 ">
		<div class="jumbotron-fluid border  py-3 bg-shadow"   style="background:#f2f8ff !important;">
			<h1 class="font-weight-bold  text-center text-primary">WAP FILE TRANSFER PROTOCOL </h1>
		</div>
	</div>
</div>	


<div class="row ">

	<div class="col-md-4">	
		<div class="jumbotron  border py-3 bg-shadow" style="height:400px; background:#f2f8ff !important;">
		<h3 class="text-primary ">Log in</h3>


		<form id="form_data">
			<input type="text" value="<?php echo $ip; ?>" class="form-control mb-3" placeholder="192.168.1.1" name="ip" id="ip" required="">
			<input type="text" value="<?php echo $username; ?>" class="form-control mb-3"  placeholder="username" name="email" id="username">
			<input type="password" value="<?php echo $password; ?>" class="form-control mb-3"  placeholder="password" name="password" id="password">
			<input type="submit" class="btn btn-primary" value="Login" id="submit" name="">
		</form>
	

</div>
</div>

	<div class="col-md-8"  id="box_main" style="position: relative;">

<div class="jumbotron  border py-3 bg-shadow" style=" height:400px; background:#f2f8ff !important;
overflow-y:auto;">

	<div class="pb-3">

<button type="btn" class="btn" id="bak" disabled ><i class="fa fa-arrow-left"></i></button>


</div>

			
<div class="m-auto  text-center total_list d-none" >

</div>
</div>

</div>
	
<div class="col-md-12">
<div class="jumbotron py-1  border d-flex flex-column bg-shadow" style=" background:#f2f8ff !important;">
	<div>
	<h3 >LIVE STATUS</h3>
	<h6 class="text-success response d-none" ></h6 >
</div>
<div>
	<h6 id="file_name"></h6>
	</div>		
		<div class="col-md-12 py-2 border d-none" id="file_text"></div>
		<div>
	<button type="button" class="btn btn-primary float-right  my-3 d-none"  id="save"><i class="fa fa-save"></i> save</button>
</div>

	</div>
</div>
</div>
</div>
</div>

		<div class="col-md-2 bg-white  m-0 px-0  border shadow-lg" id="box" style="display:none; position: absolute;z-index: 99999">
		<ul class="m-0 p-0" >
			

		<li class=" pointer px-3 text-dark box_in"  list_name="Edit" location="edit.php"><i class="fa fa-edit"></i>  Edit</li>
		<li class=" pointer px-3 text-dark box_in"  list_name="Copy" location="copy"><i class="fa fa-copy "></i> Copy</li>
		<li class=" pointer px-3 text-dark box_in"  list_name="Move" location="move"><i class="fa  fa-folder"></i> Move</li>
		
		<li class=" pointer px-3 text-dark box_in"  list_name="Rename" location="rename"><i class="fa fa-edit"></i> Rename</li>

		<li class=" pointer px-3 text-dark box_in"  list_name="Download" location="download.php"><i class="fa fa-download"></i> Download</li>

		<li class=" pointer px-3 text-dark box_in"  list_name="Delate" location="delate.php"><i class="fa fa-trash"></i> Delate</li>	

		<li class=" pointer px-3 text-dark box_in"  list_name="Folder" location="folder"><i class="fa fa-folder"></i> New Folder</li>

		<li class=" pointer px-3 text-dark box_in"  list_name="File" location="text"><i class="fa fa-edit"></i> Text File</li>
		</ul>
			</div>



<!-- Modal -->
<div class="modal fade" id="show_model" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Chosse Folder</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body"  id="mbody">
        
      </div>
      <div class="modal-footer d-flex justify-content-between">
      	<div>
      	<span id="wr_path"></span>
		</div>
      	<div>
               <button type="button" class="btn btn-primary d-none" id="copy">Copy</button>
               <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
           </div>
      </div>
    </div>
  </div>
</div>




	






<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
<script src="js/index.js"></script>

</body>
</html>
