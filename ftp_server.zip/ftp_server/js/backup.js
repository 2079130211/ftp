$(document).ready(function(){		
	$("#form_data").submit(function(e){
		e.preventDefault(); 		
		$.ajax({
			type:"POST",
			url:"php/login.php",
			data:new FormData(this),
			cache:false,
			processData: false,
            contentType: false,
			beforeSend:function(){
				$(".total_list").removeClass("d-none");
				$(".total_list").html('<i class="fa fa-spinner fa-spin" style="font-size:50px;"></i><p>Please wait ... </p>');
				$(".response").removeClass("d-none");
				$(".response").html("<h4 class='text-danger'>Connecting To Server</h4>");
			},
			success:function(response){
				if(response.trim() != "not connect")
				{
// console.log(response);
				$(".total_list").html("");
				$(".response").html("<h4 class='text-success'>Connected</h4>");
				var all_data =  JSON.parse(response.trim());
				var i;
				var data = [];
					for(i=2; i<all_data[1].length; i++)
				{
					var folder  = "<div class='border p-2 mb-3 d-flex text-left list align-items-center' back_path='main' path='main' type='folder' name='"+all_data[1][i]+"'> <i class='fa fa-folder text-warning mr-3' style='font-size:30px'></i> <labal class='lable_name'> "+ all_data[1][i] +"</labal></div>"
						$(".total_list").append(folder);	
				}
				for(i=0; i<all_data[0].length; i++)
				{
					var file  = "<div class='border p-2 mb-3 d-flex text-left list align-items-center' back_path='main' path='main' type='file' name='"+all_data[0][i]+"'> <i class='fa fa-file text-info mr-3' style='font-size:30px'></i> <labal class='lable_name'> "+ all_data[0][i] +"</labal></div>"
						$(".total_list").append(file);
				}
 				right_click();
				upload();	
				return false;
			}
			else
			{

				$(".response").html("<h4 class='text-danger'>Connecting To error Please try again ...</h4>");
			}

		}
		});

	});
});





// sign in 

function right_click()
{
	dbclick();

			$(".list").each(function(){
				$(this).click(function(){					
				$(".list").each(function(){
					$(this).removeClass("list_clik");
				});
				$(this).addClass("list_clik");
				}); // color //

				var etag = this;

			$(this).on("contextmenu",function(e){
				var name = $(this).attr("name");
				var type = $(this).attr("type");

				// $(".list").each(function(){
				// 	$(this).removeClass("list_clik");
				// });
				// $(this).addClass("list_clik");
				

				e.preventDefault();				
					var top =  e.pageY;
					var left = e.pageX;
				$("#box").css({
					display:"block",
					top:top+"px",
					left:left+"px"
				});


				if($("#box").css('display') == "block")
				{

				$("*").scroll(function(){
				$("#box").css({display:"none"});
				});

				}

				$(document).click(function(e){
					if($(e.target).closest("#box").length == 0)
					{
						$("#box").css({display:"none"});
					}
					else
					{
						$("#box").css({display:"none"});
					}
				});



				$(".box_in").each(function(){
				this.onclick = function(){
					var page_name = $(this).attr("location");				
					page_load(page_name,name,type,etag);				
				}
			});

			});
			});
}




/// right click left click // dbale click//



function page_load(url,name,type,etag)
{

	if(url == "copy")
	{

		copy_file(url,name,type);	
	}

	else if(url == "move")
	{		
		// move_file(url,name,type);		
	}

	else if(url == "rename")
	{
			rename(etag,url,name,type);
	}

	else if(url == "folder" || url == "text" )
	{
		new_file(url,name,type);
				
	}
	else
	{

		$.ajax({
				type:"post",
				url:"php/"+url,
				cache:false,
				data:{
						file_name:name,
						file_type:type
					},
				beforeSend:function()
				{
				
						if(url == "download.php")
						{
						$(".response").removeClass("d-none");
						$(".response").html("<h4 class='text-danger'>Downloading Please Wait... </h4>");
						$("#box").css({display:"none"});
						}

						if(url == "edit.php")
						{
						$(".response").removeClass("d-none");
						$(".response").html("<h4 class='text-danger '>Please Wait... </h4>");
						$("#box").css({display:"none"});
						}

			},
			success:function(response)
			{
								if(url == "edit.php")
								{
											if(response.trim() != "fail")
												{
													$(".response").html("<h4 class='text-success'>Please Edit File And Click On Save Button</h4>");
												var details = JSON.parse(response);													
												$("#file_name").html(details[1]);
												$("#file_text").attr("contenteditable",true);
												$("#file_text").focus();
												$("#file_text").addClass("border");
												$("#file_text").html(details[0]);
												$("#save,#file_text").removeClass("d-none");
					
												}
												else
												{
													$(".response").html("<h4 class='text-dark'>"+response+"</h4>");									
												}
								}

								if(url == "download.php")
								{
												if(response.trim() =="success")
												{							
												// $(".response").html("<h4>success</h4>");
												var a = document.createElement("A");
												var f_name = [];
											 	a.href = "php/"+name; 
											 	f_name = name.split(".");
											 	a.download = f_name[0]; 

											 	a.click();

											 	delate(name,type);							 
																
													}


												else
												{
													$(".response").html("<h4>"+response+"</h4>");									
												}

								}

									if(url == "delate.php")
								{
											if(response.trim() == "success")
												{
												var details = JSON.parse(response);	
												$(".response").html("<h4 class='text-success'>"+response+"</h4>");											  
											 
												
												}
												else
												{
													$(".response").html("<h4 class='text-dark'>"+response+"</h4>");									
												}
								}


				return false;

		}


	

					});
	
	}

	}

$(document).ready(function(){
	$("#save").click(function(e){
		e.preventDefault();
		var name = $("#file_name").html();
		var type = $("#file_text").html();


		var type1 = type.replace("<pre>","");
		var type2 = type1.replace("</pre>","");


		var list = $(".list");
		var back_path = $(list[0]).attr("back_path");

		$.ajax({
			type:"post",
			url:"php/edit_upload.php",
			data:{
				file_name:name,
				file_type:type2,
				path:back_path
			},
			cache:false,
			beforeSend:function(){
				$(".response").removeClass("d-none");
				$(".response").html("<h4 class='text-danger'>please wait... </h4>");
			},
			success:function(response){

				if(response.trim() == "success")
				{
								$(".response").html("<h4 class='text-success'>success</h4>");
								
								$("#file_name").addClass("d-none");

								$("#file_text,#save").addClass("d-none");
				}
				else
				{
					$(".response").html("<h4 class='text-success'>"+response+"</h4>");
									}

				

			}
		});
	});
});
	
/////////// upload////////

function upload()
{

	$("#box_main").on('dragover',function(e){
		e.preventDefault();
	});

	$("#box_main").on('drop',function(e){
		e.preventDefault();

		var files = e.originalEvent.dataTransfer.files[0];

		var name = files.name;

			var list = $(".list");
		var back_path = $(list[0]).attr("back_path");
		var form = new FormData();

		form.append("file",files);
		form.append("back_path",back_path);	
		$.ajax({
			type:"post",
			url:"php/new_upload.php",
			data:form,
			cache:false,
			processData:false,
			contentType:false,
			beforeSend:function(){
				$(".response").removeClass("d-none");
				$(".response").html("<h4 class='text-danger'>please wait... </h4>");

			},
			success:function(response){
				if(response.trim() == "success")
				{
					$(".response").html("<h4 class='text-success'>"+name+" Upload success</h4>");
					$("#save,#file_text").addClass("d-none");
								
					setTimeout(function()
								{
										
										
										$("#form_data").submit();
								},3000);

				}
				else
				{
					$(".response").html("<h4 class='text-success'>"+response+"</h4>");
				}


			}
		});
	});

}


//auto login//

$(document).ready(function(e){
 
var ip  = $("#ip").val();
var username  = $("#username").val();
var password  = $("#password").val();

	if(ip != "" && username != ""  && password != "" )
	{
		$("#form_data").submit();
	}	

});


////////// dbclick///

function dbclick(){

				$(".list").each(function(){
				this.ondblclick = function(){

					var name = $(this).attr("name");
					var type = $(this).attr("type");


					var back_path = $(this).attr("back_path");


					var url;

					if(type == "folder")
					{
						url = "php/open_dir.php";						

					}
					else
					{
						url = "php/edit.php";
					}

					$.ajax({
						type:"post",
						url:url,
						data:{
							file_name:name,
							file_type:type
						},
						cache:false,
						beforeSend:function(){
								if(type == "folder")
							{
								$(".total_list").html('<i class="fa fa-spinner fa-spin" style="font-size:50px;"></i><p>Please wait ... </p>');
							}
				$(".response").removeClass("d-none");
				$(".response").html("<h4 class='text-danger'>please wait... </h4>");
				
			
						},
						success:function(response){

							// console.log(response);
				if(type == "folder")
					{
//////////////////


				if(response.trim() != "not connect")
				{


				$(".total_list").html("");				

				var all_data =  JSON.parse(response.trim());
				var i;
				var data = [];

								for(i=2; i<all_data[1].length; i++)
				{
					data = all_data[1][i].split("*");

					var folder  = "<div class='border p-2 mb-3 d-flex text-left list align-items-center' back_path='"+data[2]+"' path='"+data[1]+"' type='folder' name='"+data[0]+"'> <i class='fa fa-folder text-warning mr-3' style='font-size:30px'></i> <labal class='lable_name'> "+ data[0] +"</labal></div>"
						$(".total_list").append(folder);	
				}


				for(i=0; i<all_data[0].length; i++)
				{
					data = all_data[0][i].split("*");

					var file  = "<div class='border p-2 mb-3 d-flex text-left list align-items-center' back_path='"+data[2]+"'  path='"+data[1]+"' type='file' name='"+data[0]+"'> <i class='fa fa-file text-info mr-3' style='font-size:30px'></i> <labal class='lable_name'> "+ data[0] +"</labal></div>"
						$(".total_list").append(file);
				
				}

				$(".response").html("<h4 class='text-success'>Connected</h4>");

				
				
				right_click();
				upload();	
				open_folder();
				go_back_page(back_path,name,type);	

				

				return false;
				
			}
			else
			{

				$(".response").html("<h4 class='text-danger'>Connecting To error Please try again ...</h4>");
			}
				
//////////////
					}
					else
					{
							if(response.trim() != "fail")
												{
							


												var details = JSON.parse(response);	
												$(".response").html("<h4 class='text-success'>Please Edit File And Click On Save Button</h4>");
												$("#file_name").html(details[1]);
												$("#file_text").attr("contenteditable",true);
												$("#file_text").focus();
												$("#file_text").addClass("border");
												$("#file_text").html(details[0]);
												$("#save,#file_text").removeClass("d-none");
			
												}
												else
												{
													$(".response").html("<h4 class='text-dark'>"+response+"</h4>");									
												}
					}


							
							

						}
					});
			

				}

				});


				}

				/////////copy///////////////////



				function copy_file(url,name,type)
				{

		$("#wr_path").html("");	
		$("#show_model").modal('show');


	$("#show_model #mbody").html("");
$(".list").each(function(){
		if($(this).attr("type") == "folder")
		{
			$("#show_model #mbody").append("<div class='border p-2 mb-3 d-flex text-left align-items-center select_folder' type='"+$(this).attr("type")+"' name='"+$(this).attr("name")+"' >"+$(this).html()+"</div>");
		}


	});

	$(".select_folder").each(function(){
		$(this).click(function(){

			$(".select_folder").removeClass(" bg-red bg-shadow");
			$(this).addClass(" bg-red bg-shadow");

			$("#copy").removeClass("d-none");


			var path = $(this).attr("name")+"/"+name;
			
			

			$("#wr_path").html(path);

			$("#copy").click(function(){
			$.ajax({
				type:"POST",
				url:"php/copy.php",
				data:{					
					path:path
				},
				cache:false,
				beforeSend:function(){
				$("#wr_path").html("Please Wait");	
				},
				success:function(response){
					
					if(response.trim() == "success")
					{
						$("#wr_path,.response").html("success");

						$("#show_model").modal('hide');

						

					}
					else
					{
							alert(response);
					}

				

				}
			});

			});

		});
	});

	
				}




/////////////open folder////


function open_folder(){
					$(".list").each(function (){
						this.ondblclick = function(){
						
					var name = $(this).attr("name");
					var type = $(this).attr("type");
					var path  = $(this).attr("path");
					
					var url;

					var  back_path =  $(this).attr("path");

						
						 if(type == "folder")
					{
						url = "php/open_dir.php";

						console.log("hello");
						console.log(name);
						console.log(type);
						console.log(path);

						
					}
					else
					{

					if(back_path != "main")
					{		type = path;
							path = name;							
							url = "php/edit.php";
					}
					else
					{
						path = name;						
						url = "php/edit.php";

					}
												
					}


					

					$.ajax({
						type:"post",
						url:url,
						data:{
							file_name:path,
							file_type:type
						},
						cache:false,
						beforeSend:function(){
							$(".response").removeClass("d-none");
							$(".response").html("<h4 class='text-danger'>please wait... </h4>");

							if(type == "folder")
							{
								$(".total_list").html('<i class="fa fa-spinner fa-spin" style="font-size:50px;"></i><p>Please wait ... </p>');

							}			
			},
						success:function(response){



				if(type == "folder")
					{
//////////////////


				if(response.trim() != "not connect")
				{

				$(".total_list").html("");

				var all_data =  JSON.parse(response.trim());
				var i;
				var data = [];

			 if(all_data.length > 0)
				{

					for(i=2; i<all_data[1].length; i++)
				{
					data = all_data[1][i].split("*");

					var folder  = "<div class='border p-2 mb-3 d-flex text-left list align-items-center' back_path='"+data[2]+"' path='"+data[1]+"' type='folder' name='"+data[0]+"'> <i class='fa fa-folder text-warning mr-3' style='font-size:30px'></i> <labal class='lable_name'> "+ data[0] +"</labal></div>"
						$(".total_list").append(folder);	
				}


				for(i=0; i<all_data[0].length; i++)
				{
					data = all_data[0][i].split("*");
					var file  = "<div class='border p-2 mb-3 d-flex text-left list align-items-center' back_path='"+data[2]+"'  path='"+data[1]+"' type='file' name='"+data[0]+"'> <i class='fa fa-file text-info mr-3' style='font-size:30px'></i> <labal class='lable_name'> "+ data[0] +"</labal></div>"
						$(".total_list").append(file);				
				}

			}
				$(".response").html("<h4 class='text-success'>Connected</h4>");
				right_click();
				upload();
				open_folder();
				go_back_page(back_path,path,type);	
				return false;
			}
			else
			{

				$(".response").html("<h4 class='text-danger'>Connecting To error Please try again ...</h4>");
			}
				
//////////////
					}
					else
					{

					
							if(response.trim() != "fail")
												{
												
												

												var details = JSON.parse(response);	
												$(".response").html("<h4 class='text-success'>Please Edit File And Click On Save Button</h4>");
												$("#file_name").html(details[1]);
												$("#file_text").attr("contenteditable",true);
												$("#file_text").focus();
												$("#file_text").addClass("border");
												$("#file_text").html(details[0]);
												$("#save,#file_text").removeClass("d-none");

												}
												else
												{
													$(".response").html("<h4 class='text-danger'>"+response+"</h4>");
												}
					}


							
							

						}
					});
			

				}

							});



				}



//////////////////new file//////////////


function new_file(url,name,type)
{
		if(url == "folder")
		{
			var folder = "fa fa-folder text-warning mr-3";
			var text = "New Folder";

			
		}
		if(url == "text" )
		{
			var folder = "fa fa-file text-info mr-3";
			var text = "New.txt";
			
		}



var div =  document.createElement("DIV");
div.className = "border p-2 mb-3 d-flex text-left list align-items-center";
div.setAttribute("type","folder");
div.setAttribute("name","hello");

var i =  document.createElement("I");
i.className = folder;
i.style.fontSize = 30+"px";

var labal =  document.createElement("LABAL");
labal.className = "lable_name";
labal.innerHTML = text;

$(labal).attr("contenteditable" ,true);



$(div).append(i);

$(div).append(labal);

$(".total_list").append(div);

$(labal).focus();

var list = $(".list");


var back_url = $(list[0]).attr("back_path");



$(labal).focusout(function(){

	var path  = labal.innerHTML;

if(back_url == "main")
{
	path =  path;
}else{
	path = back_url+"/"+path;
}


// alert(path);


		$.ajax({
					type:"post",
					url:"php/newfolder.php",
					data:{
						file_name:path,
						file_type:url
					},
					cache:false,
					beforeSend:function(){
						$(".response").removeClass("d-none");
						$(".response").html("<h4 class='text-danger'>Please Wait... </h4>");
					},
					success:function(response){

						// console.log(response);

						if(response.trim() == "success")
						{
							$(labal).removeAttr("contenteditable");

								$(".response").html("<h4 class='text-success'>success</h4>");

								setTimeout(function (){
	$(".response").addClass("d-none");$("#form_data").submit();
	},1000);
							
						}
						else
						{
								alert(response);


						}


						return false;

					}
				});
});

}

///////////rename////////////

function rename(etag,url,name,type)
{
	var name_elemnet = etag.getElementsByClassName("lable_name")[0];
			$(name_elemnet).addClass("border");
			// var oldname =  name_elemnet.innerHTML;

			$(name_elemnet).attr("contenteditable" , true);
			$(name_elemnet).focus();


			$(name_elemnet).focusout(function(){

				var newname = name_elemnet.innerHTML;


				var list = $(".list");


var back_url = $(list[0]).attr("back_path");


if(back_url != "main")
{
		name = back_url+"/"+name;
		newname = back_url+"/"+newname;		
}


				
				$.ajax({
					type:"post",
					url:"php/rename.php",
					data:{
						oldname:name,
						newname:newname,
						file_type:type
					},
					cache:false,
					beforeSend:function(){
						
						$(".response").removeClass("d-none");
						$(".response").html("<h4 class='text-danger '>Please Wait... </h4>");
						$("#box").css({display:"none"});
						

					},
					success:function(response){

						if(response.trim() == "success")
						{
							$(name_elemnet).removeAttr("contenteditable");
							$(name_elemnet).removeClass("border");

							$(".response").html("<h4 class='text-success'>success</h4>");
								setTimeout(function(){$(".response").addClass("d-none");$("#form_data").submit();},2000);

								
						}
						else
						{
								alert(response);

						}

					}
				});

				

			});
}



	function delate(name,type)
	{


	$.ajax({
		type:"post",
		url:"php/delate1.php",
		data:{
				file_name:name,
				file_type:type
				},
				cache:false,
				beforeSend:function()
				{
		 $(".response").html("<h4 class='text-danger'>Downloading Please Wait... </h4>");
	
		},										
		success:function(response)
		{

// console.log(response);
			
if(response.trim() == "success")
{
	
$(".response").html("<h4>success</h4>");
 

}

	else
{
		$(".response").html("<h4>"+response+"</h4>");	

		
}

}
	
});

}

function go_back_page(back_path,name,type)
{
 $("#bak").removeAttr("disabled");
 $("#bak").removeClass("notallw_od");
 $("#bak").addClass("pointer btn-primary");

// console.log(back_path);

document.getElementById("bak").onclick = function(){
history_open(back_path,name,type);

 }
}



function history_open(back_path,name,type)
{

	if(back_path == "main")
	{
		url = "php/login2.php";
		console.log(back_path);		
	}
	else
	{

		// var back_path1 = back_path.split("/");
		//  for(i=0; i<back_path1.length-1; i++)
		//  {
		//  	path_url[i] += "/"+back_path1[i]; 
		//  }
		console.log(back_path);
		url = "php/open_dir.php";	
	}

	
}